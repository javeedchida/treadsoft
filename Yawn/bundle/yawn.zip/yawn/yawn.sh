java -jar yawn.jar ./yawnconfig.xml
